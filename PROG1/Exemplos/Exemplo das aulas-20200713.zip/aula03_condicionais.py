a = 10
b = 20
print (a < b)
print (a > b)
print ( (a < 10) or (b < 10) )
print ( (a <= 10) or (b <= 10) )
print ( (a <= 10) and (b <= 10) )
print ( (a <= 10) and (b <= 20) )
print ( not (a <= 20) )


