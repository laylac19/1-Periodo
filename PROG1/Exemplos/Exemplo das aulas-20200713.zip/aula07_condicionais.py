preco = float ( input ("Informe o preço do produto: ") )
qtde = int ( input ("Informe a quantidade vendida: ") )
total = preco * qtde

if total <= 100 :     
    desconto = total * (3/100)
    print("Você terá um desconto de 3%" ) 
else :
    if total <= 200 :
        desconto = total * (5/100)
        print("Você terá um desconto de 5%" )
    else:
        desconto = total * (10/100)
        print("Você terá um desconto de 10%" )

total = total - desconto  
print("O total a pagar é R$ %.2f"  %total) 
