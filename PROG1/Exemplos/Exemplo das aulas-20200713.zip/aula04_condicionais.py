idade = int ( input ("Informe sua idade: ") )

if idade >=18 :
    print("Você é MAIOR de idade")
    print("Já pode tirar carteira de motorista.")

print("Fim do programa.")


