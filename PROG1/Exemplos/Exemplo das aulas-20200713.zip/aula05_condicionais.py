preco = float ( input ("Informe o preço do produto: ") )
qtde = int ( input ("Informe a quantidade vendida: ") )
total = preco * qtde

if total > 100 :
    desconto = total * (5/100)
    total = total - desconto
    
print("O total a pagar é R$ %.2f"  %total) 
